# Metridex CI Guardrails: safe smoke covering judge/admin/report/buttons paths.
# - Never fails CI. Logs what executed and what was skipped.
# - Avoids network where possible; wraps all calls in try/except.
import os, importlib, sys, inspect, time, json

APP_MODULE = os.environ.get("APP_MODULE", "server:app")
MOD_NAME = APP_MODULE.split(":")[0]

# ---- Safe env defaults (do not overwrite real secrets in prod) ----
os.environ.setdefault("TELEGRAM_TOKEN", "ci-dummy")
os.environ.setdefault("WEBHOOK_SECRET", "ci")
os.environ.setdefault("WEBHOOK_HEADER_SECRET", "ci")
os.environ.setdefault("SITE_URL", "http://127.0.0.1:8000")
os.environ.setdefault("DB_PATH", "/tmp/metridex_ci.db")
os.environ.setdefault("JUDGE_PASS_CODE", "DMCC2025")
os.environ.setdefault("JUDGE_PASS_TTL_DAYS", "60")
os.environ.setdefault("ADMIN_CHAT_ID", "1")
os.environ.setdefault("ALLOWED_CHAT_IDS", "1")
os.environ.setdefault("DEV_FREE", "1")
os.environ.setdefault("DEX_BUTTONS_ENABLED", "1")
os.environ.setdefault("DEX_STRICT_CHAIN", "1")

def log(msg): print(f"[guardrails] {msg}")

def try_call(obj, name, *args, **kwargs):
    f = getattr(obj, name, None)
    if callable(f):
        try:
            res = f(*args, **kwargs)
            log(f"{name} ✓ type={type(res).__name__}")
            return True, res
        except Exception as e:
            log(f"{name} ✗ raised: {e}")
            return False, None
    else:
        log(f"{name} — missing")
        return None, None

try:
    m = importlib.import_module(MOD_NAME)
    log(f"Imported module: {MOD_NAME}")
except Exception as e:
    log(f"Import failed: {e}")
    sys.exit(0)

# ---- 1) Reports / render paths ----
# _render_report(ctx) -> html or str
try_call(m, "_render_report", {})
# mdx_build_html_report(ctx)
try_call(m, "mdx_build_html_report", {})
# mdx_postprocess_text(text, chat_id)
try_call(m, "mdx_postprocess_text", "Hello", 0)

# ---- 2) Short reply builder (core bot answer) ----
# mdx_build_short_reply(contract, chain='ethereum')
if hasattr(m, "mdx_build_short_reply"):
    try_call(m, "mdx_build_short_reply", "0x" + "0"*40, **{"chain": "ethereum"})

# ---- 3) Buttons / share row ----
for cand in ["_ensure_action_buttons_with_share", "_ensure_buttons_primary", "_build_buttons_quickscan"]:
    if hasattr(m, cand):
        try_call(m, cand, "Sample text", [])

# ---- 4) Judge / admin checks ----
# We don't know exact names; probe common variants.
judge_candidates = [n for n in dir(m) if "judge" in n.lower()]
admin_candidates = [n for n in dir(m) if "admin" in n.lower() or "owner" in n.lower()]

log(f"Judge-like symbols: {judge_candidates[:8]}{'...' if len(judge_candidates)>8 else ''}")
log(f"Admin-like symbols: {admin_candidates[:8]}{'...' if len(admin_candidates)>8 else ''}")

for name in judge_candidates[:8]:
    obj = getattr(m, name)
    if callable(obj):
        sig = inspect.signature(obj)
        if len(sig.parameters) == 0:
            try_call(m, name)
        elif len(sig.parameters) == 1:
            try_call(m, name, 0)

for name in admin_candidates[:8]:
    obj = getattr(m, name)
    if callable(obj):
        sig = inspect.signature(obj)
        if len(sig.parameters) == 0:
            try_call(m, name)
        elif len(sig.parameters) == 1:
            try_call(m, name, 0)

# ---- 5) Dex / scan links (do not open network) ----
for cand in ["_build_dex_url", "_build_scan_url"]:
    if hasattr(m, cand):
        try_call(m, cand, "ethereum", "0x" + "0"*40)

log("Done.")
